package bit.mcnear1.agilemanager;

import android.app.Fragment;

/**
 * Created by alexmcneill on 18/05/15.
 */
public interface SwappablePage {
    public void updateCurrentPage(Fragment newPage);
}
