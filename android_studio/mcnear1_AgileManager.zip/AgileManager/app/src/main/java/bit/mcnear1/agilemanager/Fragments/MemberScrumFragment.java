package bit.mcnear1.agilemanager.Fragments;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import bit.mcnear1.agilemanager.R;

/**
 * Created by alexmcneill on 25/05/15.
 */
public class MemberScrumFragment extends Fragment {

    protected TextView mLblMemberName;
    protected LinearLayout mMemberContainer;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View v = inflater.inflate(R.layout.fragment_recent_scrum_item, container, false);
        Bundle args = getArguments();
        String scrumJsonString = args.getString("memberScrumJson");


        return v;
    }

    public class MemberTitleClickHandler implements View.OnClickListener
    {
        @Override
        public void onClick(View view) {
            if(mMemberContainer.getVisibility() == View.VISIBLE)
            {
                mMemberContainer.setVisibility(View.GONE);
            }
            else
            {
                mMemberContainer.setVisibility(View.VISIBLE);
            }
        }
    }
}
